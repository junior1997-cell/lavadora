<?php
header("Location: login.html");
?>