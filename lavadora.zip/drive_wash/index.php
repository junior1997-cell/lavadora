<?php 
//redireccionar a la vista de login
header ('Location: vistas/virtua/index.html');
?>